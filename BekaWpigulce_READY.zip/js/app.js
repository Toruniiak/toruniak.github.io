document.querySelectorAll("button,a").forEach(el=>{
el.addEventListener("click",()=>{
el.style.transform="scale(0.9)";
setTimeout(()=>el.style.transform="scale(1)",150);
});
});
